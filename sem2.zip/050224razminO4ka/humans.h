#include<iostream>
#include <random>

using namespace std;

int min(int a, int b)
{
    if (a<b) a=b;
    return a;
}

class Human
{
private:
    string name;
    int year, mounth,day;
    float mass;

    void init()
    {
        name="John Doe";
        year=1900;
        mounth=01;
        day=01;
        mass=60;
    }
    void destroy()
    {
        name=nullptr;
        year=0;
        mass=0;
    }
public:
    Human ()
    {
        init();
    }
    Human (string s, int n, float f)
    {
        name=s;
        year=n;
        mass=f;
    }
    string getName()
    {
        return name;
    }
    int getBD()
    {
        return year*10000+mounth*100+day;
    }
    float getMass()
    {
        return mass;
    }
    bool isRightLarger(string s, Human h)
    {
        bool b;
        if (s=="Mass") b=mass<h.mass;
        else if (s=="BD") b=getBD()<h.getBD();
        else if (s=="Name") b=name<h.name;
        return b;
    }
    void setName(string s)
    {
        name=s;
    }
    void setMass(float f)
    {
        mass=f;
    }
    Human operator= ( const Human & h)
    {
        mass=h.mass;
        name=h.name;
        year=h.year;
        mounth=h.mounth;
        day=h.day;
        return (*this);
    }
    friend ostream & operator<< (ostream & stream, const Human & h)
    {
        stream<<h.name;
        stream<<'|';
        stream<<h.year<<'.'<<h.mounth<<'.'<<h.day;
        stream<<'|';
        stream<<h.mass;
        return stream;
    }
    friend istream & operator >> (istream & in, Human & h)
    {
        getline(in, h.name);
        in>>h.year;
        in>>h.mass;
        return in;
    }
    void giveName()
    {
        string s;
        char c;
        random_device rd;  
        mt19937 gen(rd());  
        uniform_int_distribution<> dist(65, 90);  
        c=dist(gen);
        s+=c;

        for (int j{0}; j<4; j++)
        {
            mt19937 gen(rd());  
            uniform_int_distribution<> dist(97, 122);  
            s+=dist(gen);
        }
        name=s;
    }
    void giveYear()
    {
        int n;
        random_device rd;  
        mt19937 gen(rd());  
        uniform_int_distribution<> dist(0, 125);  
        n=dist(gen);
        year+=n;
    }
    void giveMounth()
    {
        int n;
        random_device rd;  
        mt19937 gen(rd());  
        uniform_int_distribution<> dist(1, 12);  
        n=dist(gen);
        mounth=n;
    }
    void giveDay()
    {
        int m;
        if ((mounth==1)||(mounth==3)||(mounth==5)||(mounth==7)||(mounth==8)||(mounth==10)||(mounth==12)) m=31;
        else if ((mounth==2)&&((year%400!=0)||(year%4!=0))) m=28;
        else if (mounth==2) m=29;
        else m=30;
        random_device rd;  
        mt19937 gen(rd());  
        uniform_int_distribution<> dist(1, m);  
        day=dist(gen);
    }
    void giveBD()
    {
        giveYear();
        giveMounth();
        giveDay();
    }
    void giveMass()
    {
        float f;
        random_device rd;  
        mt19937 gen(rd());  
        uniform_int_distribution<> dist(40, 210);  
        f=dist(gen);
        mass=f;
    }
    void giveData()
    {
        giveName();
        giveMass();
        giveBD();
    }
};

class HumanList
{
private:
int number;
Human *list;
    void init()
    {
        list=new Human[number];
        for (int i{0}; i<number; i++)
        {
            Human h;
            list[i]=h;
        }
    }
    void destroy()
    {
        delete [] list;
        list=nullptr;
    }
public:
    HumanList()
    {
        number=3;
        init();
    }
    HumanList(int n)
    {
        number=n;
        init();
    }
    void giveHumans()
    {
        for (int i{0}; i<number; i++) list[i].giveData();
    }
    void print()
    {
        for (int i{0}; i<number; i++) 
            {
                cout<<list[i]<<endl;
            }
    }
    friend istream & operator>> (istream & stream, HumanList &hl)
    {
        cout<<"Add a number of people ";
        stream>>hl.number;
        for (int i{0}; i<hl.number; i++) 
            {
                cout<<"Add a person data ";
                stream>>hl.list[i];
            }
        return stream; 
    }
    friend ostream & operator<< (ostream & stream, HumanList &hl)
    {
        for (int i{0}; i<hl.number; i++) 
            {
                stream<<hl.list[i]<<endl;
            }
        return stream; 
    }

    HumanList operator= (const HumanList &hl)
    {
        destroy();
        number=hl.number;
        list=hl.list;    
        return (*this);
    }

void bubble_sort(string s)
    { 
    Human temp;
    if (s=="Mass")
        for (int j{1}; j<number; j++)
        for (int i{0}; i<number-j; i++) 
        {
            if(list[i+1].getMass()<list[i].getMass())
            {
                temp=list[i];
                list[i]=list[i+1];
                list[i+1]=temp;
            }
        }
    else if (s=="Name")
        for (int j{1}; j<number; j++)
        for (int i{0}; i<number-j; i++)
        {
            if(list[i+1].getName()<list[i].getName())
            {
                temp=list[i];
                list[i]=list[i+1];
                list[i+1]=temp;
            }
        }
    else if (s=="BD")
        for (int j{1}; j<number; j++)
        for (int i{0}; i<number-j; i++)
        {
            if(list[i+1].getBD()<list[i].getBD())
            {
                temp=list[i];
                list[i]=list[i+1];
                list[i+1]=temp;
            }
        } 
    else cout<<"Wrong input";   
    
        // for (int j{1}; j<number; j++)
        // for (int i{0}; i<number-j; i++) 
        //     {
        //         if(list[i+1].isRightLarger(s,list[i]))
        //         {
        //             temp=list[i];
        //             list[i]=list[i+1];
        //             list[i+1]=temp;
        //         }
        //     }     
    }
void selection_sort(string s)
    {
        int min; 
        Human temp;
        for (int i = 0; i<number; i++) 
        {
            min=i;
            for (int j = i; j<number; j++)
                if (list[j].isRightLarger(s,list[min])) min=j;
            temp=list[i];
            list[i]=list[min];
            list[min]=temp;
        }
    }
void shell_sort(string s)
    {
        int i, j, step;
        Human temp;
        for (step=number/2; step > 0; step /= 2)
            for (i = step; i < number; i++)
            {
                temp = list[i];
                for (j = i; j >= step; j -= step)
                {
                    if (temp.isRightLarger(s,list[j-step])) list[j] = list[j - step];
                    else break;
                }
                list[j] = temp;
            }
    }
void merge_sort(string s)
    {
        int BlockSizeIterator, BlockIterator, LeftBlockIterator, RightBlockIterator, MergeIterator, LeftBorder, MidBorder, RightBorder;
        for (BlockSizeIterator = 1; BlockSizeIterator < number; BlockSizeIterator *= 2)
        {
            for (BlockIterator = 0; BlockIterator < number - BlockSizeIterator; BlockIterator += 2 * BlockSizeIterator)
            {
                //Производим слияние с сортировкой пары блоков начинающуюся с элемента BlockIterator
                //левый размером BlockSizeIterator, правый размером BlockSizeIterator или меньше
                LeftBlockIterator = 0;
                RightBlockIterator = 0;
                LeftBorder = BlockIterator;
                MidBorder = BlockIterator + BlockSizeIterator;
                RightBorder = BlockIterator + 2 * BlockSizeIterator;
                RightBorder = (RightBorder < number) ? RightBorder : number;
                Human* SortedBlock = new Human[RightBorder - LeftBorder];

                //Пока в обоих массивах есть элементы выбираем меньший из них и заносим в отсортированный блок
                while (LeftBorder + LeftBlockIterator < MidBorder && MidBorder + RightBlockIterator < RightBorder)
                {
                    if (list[LeftBorder + LeftBlockIterator].isRightLarger(s,list[MidBorder + RightBlockIterator]))
                    {
                        SortedBlock[LeftBlockIterator + RightBlockIterator] = list[LeftBorder + LeftBlockIterator];
                        LeftBlockIterator += 1;
                    }
                    else
                    {
                        SortedBlock[LeftBlockIterator + RightBlockIterator] = list[MidBorder + RightBlockIterator];
                        RightBlockIterator += 1;
                    }
                }
                //После этого заносим оставшиеся элементы из левого или правого блока
                while (LeftBorder + LeftBlockIterator < MidBorder)
                {
                    SortedBlock[LeftBlockIterator + RightBlockIterator] = list[LeftBorder + LeftBlockIterator];
                    LeftBlockIterator += 1;
                }
                while (MidBorder + RightBlockIterator < RightBorder)
                {
                    SortedBlock[LeftBlockIterator + RightBlockIterator] = list[MidBorder + RightBlockIterator];
                    RightBlockIterator += 1;
                }

                for (MergeIterator = 0; MergeIterator < LeftBlockIterator + RightBlockIterator; MergeIterator++)
                {
                    list[LeftBorder + MergeIterator] = SortedBlock[MergeIterator];
                }
                delete[] SortedBlock;
            }
        }
    }
void insertion_sort(string s)
    {   
        for(int j{1};j<number;j++)
        {
            Human temp=list[j];
            int i=j-1;
            while(i >= 0 &&  temp.isRightLarger(s,list[i]))
            {
                list[i+1]=list[i];
                i--;
            }
            list[i+1]=temp;
        }
    }
void tim_sort(string s){}

void heapsort(string s)
    {
        
    }
};


