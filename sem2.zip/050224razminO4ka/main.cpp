#include<iostream>
#include "humans.h"

using namespace std;
void start(HumanList hl, string s)
{
    cout<<"Call a command by a number"<<endl;
    cout<<"1 to use a bubble sort"<<endl;
    cout<<"2 to use a selection sort"<<endl;
    cout<<"3 to use a Shell sort"<<endl;
    cout<<"4 to use a merge sort"<<endl;
    cout<<"5 to use a insertion sort"<<endl;
    int n;
    cin>>n;
    switch (n)
    {
    case 0:
        break;
    case 1:
    hl.bubble_sort(s);
        break;
    case 2:
    hl.selection_sort("Mass");
        break;
    case 3:
    hl.shell_sort("Mass");
        break;
    case 4:
    hl.merge_sort("Mass");
        break;
    case 5:
    hl.insertion_sort("Mass");
        break;
    case 6:
        break;
    case 7:
        break;
    case 8:
        break;   
    default:
        break;
    }
    cout<<hl<<endl;
}

int main()
{
    HumanList hl(4);
    hl.giveHumans();
    cout<<hl<<endl;

    string s;
    s="Mass";



}