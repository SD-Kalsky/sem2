#include<iostream>

using namespace std;
void merge(int *a, int n)
{
  int mid = n / 2; // находим середину сортируемой последовательности
    if (n % 2 == 1) mid++;
  int h = 1; // шаг
  // выделяем память под формируемую последовательность
  int *c = (int*)malloc(n * sizeof(int));
  int step;
  while (h < n) 
  {
    step = h;
    int i = 0;   // индекс первого пути
    int j = mid; // индекс второго пути
    int k = 0;   // индекс элемента в результирующей последовательности
    while (step <= mid) 
    {
      while ((i < step) && (j < n) && (j < (mid + step))) 
      { // пока не дошли до конца пути
        // заполняем следующий элемент формируемой последовательности
        // меньшим из двух просматриваемых
        if (a[i] < a[j])  
        {
          c[k] = a[i];
          i++; k++;
        }
        else {
          c[k] = a[j];
          j++; k++;
        }
      }
      while (i < step) 
      { // переписываем оставшиеся элементы первого пути (если второй кончился раньше)
        c[k] = a[i];
        i++; k++;
      }
      while ((j < (mid + step)) && (j<n)) 
      {  // переписываем оставшиеся элементы второго пути (если первый кончился раньше)
        c[k] = a[j];
        j++; k++;
      }
      step = step + h; // переходим к следующему этапу
    }
    h = h * 2;
    // Переносим упорядоченную последовательность (промежуточный вариант) в исходный массив
    for (i = 0; i<n; i++)
      a[i] = c[i];
  }
}
int * makearray(int n)
{
    int* a = new int[n];
    cout<<"Enter the value of the vertice"<<endl;
    cin>>a[0];
    cout<<"Enter indexes of the conneted vertices"<<endl;
    for (int i=1;i<n;i++)
    cin>>a[i];
    return a;
}
void printarray(int *a, int size)
{
for (int i=0;i<size;i++)
    cout<<a[i];
}
class Graph
{
private:
int number = 1;
int **elements;// Первый элемент подмассива - значение, следующие  - индексы соединенных графов
void destroy()
{
    delete [] elements;
    elements=nullptr;
}
void init()
{
    int i, j;
    elements = new int *[number];
    for (i = 0; i < number; i++)
      {
        elements[i] = new int[number];
        elements[i][0] = 1;
        elements[i][1] = i+1;
        for (j = 2; j < number; j++)
            elements[i][j] = number+1;
      }
      elements[number-1][1] = number+1;
}
public:
Graph()
{
    init();
}
Graph(int n)
{
    number=n;
    init();
}
void setValues()
{
    for (int i = 0; i < number; i++)
    {
        cout<<"Add value of the vertice "<<i<<endl;
        cin>>elements[i][0];
    }
}
void setNeighbours(int i, int *a)
{
        cout<<"Add neighbours of the vertice "<<endl;
        for (int j = 1; j < number; j++)
            elements[i][j]=a[j-1];
}
friend istream & operator>> (istream & in, Graph & q)
{
    for (int i = 0; i < q.number; i++)
      {
        cout<<"Add value of the vertice "<<i<<endl;
        cin>>q.elements[i][0];
        cout<<"Add neighbours of the vertice "<<i<<endl;
        for (int j = 1; j < q.number; j++)
            cin>>q.elements[i][j];
      }
      return in;
}
void setVertice(int i, int *a)
{
    elements[i]=a;
}
int getNumber()
{
    return number;
}
void print()
{
    for (int i=0; i<number ; i++)
    {
        cout<< elements[i][0]<<endl;
    }
}
void print(int i)
{
        cout<< elements[i][0]<<endl;
}
void printNeigbours()
{
    for (int i=0; i<number ; i++)
    {
        for (int j=1; j<number ; j++)
        cout<< elements[i][j]<<' ';
        cout<<endl;
    }
}
void printNeigbours(int i)
{
        for (int j=1; j<number ; j++)
        cout<< elements[i][j]<<' ';
        cout<<endl;
}
void addNew()
{
    int ** elementsNew= new int *[number+1];
    int i, j;
    for (i = 0; i < number; i++)
    {
        elementsNew[i] = new int [number+1];
        for (j = 0; j < number; j++)
            elementsNew[i][j] = elements[i][j];
        elementsNew[i][number] = number+1;
    }
    elementsNew[number]=makearray(number+1);
    delete [] elements;
    elements=elementsNew;
    number++;
}
void sort()
{
    
    for (int j=0; j<number; j++)
    {
        int *a =new int [number-1];
        for (int i=0; i<number-1; i++)
            a[i]=elements[j][i+1];
        merge(a, number-1);
        for (int i=0; i<number-1; i++)
            elements[j][i+1]=a[i];
    }
}
void removeDoublers()
{
    for (int i=0; i<number; i++)
    {
        for(int j=1;j<number; j++)
        {
            int a=elements[i][j];
            for(int k=j+1;k<number; k++)
                if (elements[i][k]==a)
                    elements[i][j]=number+1;
        }
    }
    sort();
}
void connectNeighbour()
{
    removeDoublers();
    for(int k=0;k<number; k++)
    for(int i=1;i<number; i++)
    {
        for(int j=k+1;j<number;j++)
            if (elements[k][i]==j+1)
            {
                int l=number;
                while(l>1)
                {
                    if (elements[j][l]==number+1)
                    {
                        elements[j][l]=k+1;
                        break;
                    }
                    else
                        l--;
                }
                if (l==1) elements[j][l]=k+1;
            }
    }
    sort();
}
bool isNeighbour(int a, int b)
{
    bool bo=false;
    for (int i=0;i<number; i++)
    if (elements[a-1][i]==b){bo=true; break;}
    return bo;
}

int minpath(int a, int b)
{
    int min, l=0;
    if (isNeighbour(a,b)) l++;
    else 
        for (int j=1; j<number; j++)
            {
                min=minpath(elements[a][j],b);
            }
    return l;
}
        
};