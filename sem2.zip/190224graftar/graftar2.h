#include<iostream>

using namespace std;

class vertice
{
private:
int value,number;
int* connections;
void init()
{
    connections=new int[number];
    for (int i=0;i<number-1; i++)
    connections[i]=i+1;
    connections[number]=-1;
}
public:
vertice()
{value=1; number=3; init();}
vertice(int n)
{value=1; number=n; init();}
vertice(int i, int n)
{value=i; number=n; init();}


};

class graph
{
private:
public:
};