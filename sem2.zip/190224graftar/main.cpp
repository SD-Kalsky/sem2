#include<iostream>
#include"graftar.h"

using namespace std;

int main()
{
    int number=4;
    Graph q(number);

    // int *a =new int [number]{2,2,3};
    // printarray(a,number);
    //printarray(a,number);
    // a.addNew();
    // a.print();
    // a.printNeigbours();
    
    for(int i=0;i<number;i++)
    {
        int* a = new int[number];
        a[0]=i;
        for(int j=1; j<number; j++)
        if(number+1>i+j+1)
            a[j]=i+j+1;
        else 
            a[j]=number+1;
        q.setVertice(i,a);
    }
    q.removeDoublers();
    // cout<<q.minpath(1,4);
    q.printNeigbours();
    return 0;
}