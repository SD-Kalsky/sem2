#include <iostream>
#include <vector>
#include <queue>
#include "classes.h"
using namespace std;


int main() 
{
    int n, m;
    cin >> n >> m;
    vector<vector<int>> grid(n, vector<int>(m));
    int startX, startY, endX, endY;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> grid[i][j];
            if (grid[i][j] == 2) {
                startX = i;
                startY = j;
            }
            else if (grid[i][j] == 3) {
                endX = i;
                endY = j;
            }
        }
    }
    int maxTurns;
    cin >> maxTurns;

    int minTime = bfs(grid, startX, startY, endX, endY, maxTurns);
    cout << minTime << endl;

    return 0;
}