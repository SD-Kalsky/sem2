#include <iostream>
#include <fstream>
#include "classes.h"

using namespace std;

int main() 
{
    ifstream file("input.txt");
    int rows, cols;
    file>>rows>>cols;
    char grid[100][100];
    for (int i = 0; i < rows; ++i) 
    {
        for (int j = 0; j < cols; ++j) 
        {
            file >> grid[i][j];
        }
    }
    file.close();
    int count = 0;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (grid[i][j] == '#') {
                count += countIslands(grid, rows, cols, i, j);
            }
        }
    }
    cout<<count<<endl;
    return 0;
}