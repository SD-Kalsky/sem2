#include<iostream>
#include<string>
using namespace std;

class transport_grid
{
private:
int number;
int **stops;
string *names;
void init()
{
    stops=new int* [number];
    names=new string [number];
    for(int i=0; i<number; i++)
    {
        stops[i]=new int[2];
        for(int j=0;j<2;j++)
            {
                stops[i][j]=0;
            }
        names[i]="stop #"+to_string(i+1);
    } 
    
}
void destroy()
{
    int i=0;
    while(i<number)
    {
        delete [] stops[i];
        stops[i]=nullptr;
        i++;
    }
    delete [] stops;
    stops=nullptr;
}
public:
transport_grid()
{
    number=3;
    init();
}
transport_grid(int n)
{
    number=n;
    init(); 
}
void add_stops(int ** a)
{
    for(int i=0;i<number;i++)
    {
        for(int j=0;j<a[i][0];j++)
            {
                stops[i][j]=a[i][j];
            }
    }
}
void null_stops()
{
    for(int i=0;i<number;i++)
    {
        for(int j=0;j<stops[i][0];j++)
        {
            stops[i][j]=0;
        }
    }
}
void auto_add_stops()
{
    int i=0;
    while(i<number)
    {
        delete [] stops[i];
        stops[i]=nullptr;
        i++;
    }
    i=1;
    stops[0] =new int [3];
    stops[0][0]=2;
    stops[0][1]=1;
    stops[0][2]=number;
    while(i<number)
    {
        stops[i] =new int [3];
        stops[i][0]=3;
        stops[i][1]=i-1;
        stops[i][2]=i+1;
        i++;
    }
    stops[number-1] =new int [2];
    stops[number-1][0]=2;
    stops[number-1][1]=0;
}
void print_stops()
{
    for(int i=0;i<number;i++)
    {
        cout<<names[i]<<": ";
        for(int j=1;j<stops[i][0];j++)
        {
            cout<<stops[i][j]+1<<' ';
        }
        cout<<endl;
    }
}
void print_stops(int i)
{
    cout<<names[i]<<": ";
    for(int j=1;j<stops[i][0];j++)
    {
        cout<<stops[i][j]<<' ';
    }
    cout<<endl;
}
void print_stops(int i, string s)
{
    if(s=="name") cout<<names[i];
}
void rename(int n, string s)
{
    names[n]=s;
}
void add_stop(int n,int *a)
{
    for(int i=0;i<stops[i][0];i++)
        stops[n][i]=a[i];
}
void add_stop(int n)
{
    int in;
    cout<<"Add stops by "<<names[n]<<endl;
    for(int i=0;i<stops[i][0];i++)
    {
        step: cin>>in;
        if(in-1>=number) {cout<<"Wrong input: there ain't "<<in<<"th stop. Add again"<<endl; goto step;}
        if(in-1==n) {cout<<"Wrong input: its next stop can't be itself. Add again"<<endl; goto step;}
        stops[n][i]=in;
    }
}
bool isThereRoute(int a, int b)
{
    int i=0;
    bool br=false;
    while(i<stops[a][0])
    {
        if(stops[a][i]==b) {br=true; break;}
        i++;
    }
    return br;
}
bool isThereWay(int a, int b)
{
    int i=0;
    bool br=false;
    while(i<stops[a][0])
    {
        if(stops[a][i]==b) {br=true; break;}
        i++;
    }
    i=0;
    if(!br)
    while(i<stops[a][0])
    {
        if(isThereWay(stops[a][i],b)) {br=true; break;}
        i++;
    }
    return br;
}
bool isThereRoute(int a, int b, int count)
{
    int i=0, c=1;
    bool br=false;
    while(i<stops[a][0])
    {
        if((stops[a][i]==b)and(1==count)) {br=true; break;}
        i++;
    }
    i=0;
    if(!br)
    while(i<stops[a][0])
    {
        c++;
        if(isThereRoute(stops[a][i],b,count-1)and(c==count)) {br=true; break;}
        i++;
    }
    return br;
}

};