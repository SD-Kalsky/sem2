#include<iostream>
#include"classes.h"
// Задание 0. Разработать наиболее удобный формат входных данных для этой задачи.
// Задание 1. По заданной входной информации проверить возможность попасть из одной остановки на другую на одном транспорте. Проверить возможность попасть из одной остановки на другую с заданным количеством пересадок.
// Задание 2. Проверить Возможно ли с каждой остановки добраться до любой другой остановки.
// Задание 3. Проверить выполнение предыдущего условия при удалении любого из маршрутов
// Задание 4. Найти минимальное количество маршрутов удаление которых приведёт к прекращению выполнения условия задания 2. 
// Задание 5. Разработать не менее 6 различных тестов для проверки корректности работы всех алгоритмов. 

using namespace std;
int main()
{
    int n=5;
    int *arr=new int [4];
    arr[0]=0;
    arr[1]=0;
    arr[2]=0;
    arr[3]=0;
    transport_grid tg(n);
    tg.auto_add_stops();
    tg.add_stop(4, arr);


    tg.rename(0,"202th Block");
    tg.rename(1,"1th School");
    tg.rename(2,"Lenin's square");
    tg.rename(3,"Central Park");
    tg.rename(4,"Factory area");

    int a=0, b=4;
    tg.print_stops();
    if (tg.isThereRoute(a,b,1)) 
    {
        cout<<"We can go from ";
        tg.print_stops(a,"name"); 
        cout<<" to ";
        tg.print_stops(b,"name"); 
    }
    else
    {
        cout<<"We can't go from ";
        tg.print_stops(a,"name"); 
        cout<<" to ";
        tg.print_stops(b,"name"); 
    }
    return 0;
}