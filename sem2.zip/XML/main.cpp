
#include <iostream>
#include <Windows.h>
#include<string>
#include "multiplTree.h"
#include"massives.h"
using namespace std;

int main()
{

string name=("file.xml");
string s=to_string(name); 
int n=HowManyTags(s);
string *a =new string[n];

a=TagsMassive(s);
int i=0;


while(i<n);
    {  
    cout<<a[i]<<endl;
    i++;
    }

//cout<<(s);

// int i=0;
// string s;
// while(i<stoi(a[0]))
// {
//     i++;
//     s=a[i];
//     int j=i;
//     while(j<stoi(a[0]))
//     {
//         j++;
//         s=='!'+a[j];
//     }
// }
return 0;
}