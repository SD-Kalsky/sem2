#include<iostream>
#include <queue>
#include <fstream>
#include<string>

using namespace std;

int HowManyTags (string name)//Тэгтэр ахсааннарын төҥнөрөр
{
    bool isComment=false, isTag=false; 
    int count{0}, k{-1};
    char c, *buffer=new char [4];
    fstream in(name);
    if (in.is_open())
        while (!in.eof())
        {
            c=in.get();
            if(k<3) k++; 
            else {buffer[0]=buffer[1]; buffer[1]=buffer[2]; buffer[2]=buffer[3];}
            buffer[k]=c;

            if((buffer[0]=='<')and(buffer[1]=='!')and(buffer[2]=='-')and(buffer[3]=='-')){isComment=true;}             
            if ((c=='<')and(!isComment)) {isTag=true;}
            if ((c=='>')and(isTag)and(!isComment)){count++; isTag=false;}
            if ((buffer[1]=='-')and(buffer[2]=='-')and(buffer[3]=='>')) {isComment=false;}
        }
    in.close();
    return count;
}

string * TagsMassive (string name)//Тэг массыбы төҥнөрөр
{
    bool isComment=false, isTag=false;
    string s, bs; 
    int count{0},i,j{1}, k{-1};
    char c, *buffer=new char [4];
    fstream in(name);
    if (in.is_open())
        while (!in.eof())
        {
            c=in.get();
            if(k<3) k++; 
            else {buffer[0]=buffer[1]; buffer[1]=buffer[2]; buffer[2]=buffer[3];}
            buffer[k]=c;
            if((buffer[0]=='<')and(buffer[1]=='!')and(buffer[2]=='-')and(buffer[3]=='-')){isComment=true; bs="";} 
            if ((c=='<')and(!isComment)) {isTag=true; bs="";}
            if ((isTag)and(!isComment)) bs+=c;
            if ((c=='>')and(isTag)and(!isComment)){count++; isTag=false; s+=bs;}
            if ((buffer[1]=='-')and(buffer[2]=='-')and(buffer[3]=='>')) {isComment=false;}  
        }
    in.close();
    string *sarray= new string [c];
    for(i=0;i<s.size();i++)
    {
        sarray[j]+=s[i];
        if((s[i]=='>')and(s[i+1]=='<')) j++;
    }
    return sarray;
}

string * TagsMassiveWithSize (string name)//Кэтиттээх тэг массыбы төҥнөрөр
{
    bool isComment=false, isTag=false;
    string s, bs; 
    int count{0},i,j{1}, k{-1};
    char c, *buffer=new char [4];
    fstream in(name);
    if (in.is_open())
        while (!in.eof())
        {
            c=in.get();
            if(k<3) k++; 
            else {buffer[0]=buffer[1]; buffer[1]=buffer[2]; buffer[2]=buffer[3];}
            buffer[k]=c;
            if((buffer[0]=='<')and(buffer[1]=='!')and(buffer[2]=='-')and(buffer[3]=='-')){isComment=true; bs="";} 
            if ((c=='<')and(!isComment)) {isTag=true; bs="";}
            if ((isTag)and(!isComment)) bs+=c;
            if ((c=='>')and(isTag)and(!isComment)){count++; isTag=false; s+=bs;}
            if ((buffer[1]=='-')and(buffer[2]=='-')and(buffer[3]=='>')) {isComment=false;}  
        }
    in.close();
    count++;
    string *sarray= new string [count];
    sarray[0]=to_string(count);
    for(i=0;i<s.size();i++)
    {
        sarray[j]+=s[i];
        if((s[i]=='>')and(s[i+1]=='<')) j++;
    }
    return sarray;
}

// int HowManyTags2 (string name)//Тэгтэр ахсааннарын төҥнөрөр
// {
//     bool isUnarTag=false, isDualTag=false, isTag=false; 
//     int count{0}, k{-1};
//     char c, *buffer=new char [2];
//     string s="", tagname="";
//     fstream in(name);
//     if (in.is_open())
//         while (!in.eof())
//         {
//             c=in.get();
//             if(k<1) k++; 
//             else {buffer[0]=buffer[1];}
//             buffer[k]=c;

//             if(buffer[0]=='<')
//                 if ((buffer[1]=='!')or(buffer[1]=='?')) {isUnarTag=true;}
//                 else          
//                     if((buffer[1]=='/')and(isDualTag)) {isDualTag=false;}
//                     else {isDualTag=true;}
//             if(isDualTag) tagname+=c;
//             s+=c;
//             if (c=='>')
//                 if(!isDualTag){count++;cout<<"A"<<s<<"B"<<endl;  s="";}
//                 else if(isUnarTag) {isUnarTag=false; count++; cout<<"A"<<s<<"B"<<endl;  s="";}
//         }
//     in.close();
//     return count;
// }

int HowManyTags2(string str)
{
    bool isUnarTag=false, isDualTag=false, isCommentTag=false, isTag=false; 
    string tag="", s="";
    int i=0, n=str.size(), count=0;
    while (i<n)  
    {
        // if((str[i]=='<')and((str[i+1]!='!')or(str[i+1]!='?')or(str[i+1]!='/'))and(!isDualTag)and(!isCommentTag)) 
        // {
        //     isDualTag=true;
        //     i++;
        //     int j=i;
        //     while(str[j+1]!='>')
        //     {
        //         tag+=str[j];
        //         j++;
        //     }
        // }
        if((str[i]=='<')and(str[i+1]=='!')and(str[i+2]=='-')and(str[i+3]=='-')and(!isDualTag)and(!isCommentTag)) {isCommentTag=true;}
        if((str[i]=='<')and((str[i+1]=='!')or(str[i+1]=='?'))and(!isDualTag)and(!isCommentTag)) {isUnarTag=true;}
        
        if(isUnarTag) s+=str[i];
        if(isCommentTag) s+=str[i];


        // if((str[i]=='<')and(str[i+1]=='/')) 
        // {
        //     int j=0;
        //     i+=2;
        //     while(str[j+i+1]!='>')
        //     {
        //         isDualTag=false;
        //         if(tag[j]!=str[j+i]) {isDualTag=true; break;}
        //         j++;
        //     }
        // }
        if((str[i]=='>')and(isUnarTag)) {isUnarTag=false; count++; cout<<s<<endl; s="";}
        if((str[i-2]=='-')and(str[i-1]=='-')and(str[i]=='>')and(isCommentTag)) {isCommentTag=false; count++; cout<<s<<endl; s="";}
        i++;
    }
    return count;
}

string to_string(string name)
{
    char c, *buffer=new char [2];
    string b="", s="", ns="";
    fstream in(name);
    if (in.is_open())
        while (!in.eof())
        {
            c=in.get();
            s+=c;
        }
    in.close();
    int i=0, n=s.size();
    while (i<n)
    {
        if(s[i]!='\n') ns+=s[i];
        i++;
    }
    return ns;
}


queue<int> uniteQueue(queue<int> a,queue<int> b)
{
    while (!b.empty())
    {
        a.push(b.front());
        b.pop();
    }
return a;
}
class multiplTree
{
int size;
int ***vertices;// Ис-исмассып биирис элэмэҥа  - исмассып кэтитэ, иккиhэ - өрүт туhа
string **str;
void destroy()
{
    delete [] vertices;
    vertices=nullptr;
    delete [] str;
    str=nullptr;    
}
void destroy_vertice(int i)
{
    delete vertices[i];
    vertices[i]=nullptr;
    delete str[i];
    str[i]=nullptr;
}
void destroy_connetion(int i,int j)
{
    delete vertices[i][j];
    vertices[i][j]=nullptr;
}
void init()
{
    int i, j;
    vertices = new int **[size];
    str= new string *[size];
    for (i = 0; i < size-1; i++)
    {
        vertices[i] = new int *[2];
        vertices[i][0]= new int[2];
        vertices[i][1] = new int[2];
        vertices[i][0][0] = 2;
        vertices[i][0][1] = 0;
        vertices[i][1][0] = i+1;
        vertices[i][1][1] = 1;
        str[i] = new string [2];
        str[i][0] = "no_name";
        str[i][1] = "no_info";
    }
    vertices[size-1] = new int *[2];
    vertices[size-1][0]= new int[1];
    vertices[i][0][0] = 1;
    vertices[i][0][1] = 0;
    str[i] = new string [2];
    str[i][0] = "no_name";
    str[i][1] = "no_info";
}
public:
multiplTree()
{
    size=3;
    init();
}
multiplTree(int n)
{
    size=n;
    init();
}
void print() //Өрүт туhун уонна түhэр өрүттэрин бичиктиир
{
    for(int i=0;i<size;i++)
    {
        cout<<"The vertice is "<<i+1<<"th "<<" and its value is "<<vertices[i][0][1]<<" and its name is <<"<<str[i][0]<<">> and that type is <<"<<str[i][1]<<">>"<<endl;    
        for(int j=1;j<vertices[i][0][0];j++)
        {
            cout<<"its "<<j<<"th sub is "<<vertices[i][j][0]+1<<" and its additional info is "<<vertices[i][j][1]<<' '<<endl;
        }
        cout<<endl;
    }
}
bool isThereWay(int a, int b) //Биирис өрүт иккискэ түhүү уhунун биэрэр
{
    bool c{false};
    int j=1;
    while(j<vertices[a][0][0])
    {
        if(vertices[a][j][0]==b){c=true;  goto exit;}
        j++;
    }
    j=1;
    while(j<vertices[a][0][0]) 
    {
        if (isThereWay(vertices[a][j][0], b)) {c=true; goto exit;} 
        else j++;    
    }
    exit:
        return c;
}

int HowManyWays(int a, int b) //Төhө суол баарын биэрэр
{
    int n=0;
    int j=1;
        while(j<vertices[a][0][0]) 
        {
            if (isThereWay(vertices[a][j][0], b)) n+=HowManyWays(vertices[a][j][0], b);
            else 
                if(vertices[a][j][0]==b) n++;
                j++;    
        }
    return n;
}

int theWayLength(int a, int b) //Биир өрүттэн иккис өрүккэ суол уhунун булар
{
    int i{1},j{1}, l{vertices[a][j][1]};
    while (j<vertices[a][0][0])
    {
        if(vertices[a][j][0]==b){goto exit;}
        j++;
    }
    j=1;
    while (j<vertices[a][0][0])
    {
        if(isThereWay(vertices[a][j][0],b)){l+=theWayLength(vertices[a][j][0],b); goto exit;}
        j++;
    }
    exit:
    return l;
}

queue<int> getWay(int a, int b) //Биир өрүттэн иккис өрүккэ суолу биэрэр
{
    queue<int> qrr;
    qrr.push(a);
    int i{1};
    if (isThereWay(a,b)==false) goto exit;
    while (i<vertices[a][0][0])
    {
        if(vertices[a][i][0]==b){qrr.push(b); goto exit;}
        i++;
    }
    i=1;
    while (i<vertices[a][0][0])
    {
        if(isThereWay(vertices[a][i][0],b)){qrr=uniteQueue(qrr,getWay(vertices[a][i][0],b)); goto exit;}
        i++;
    }
    exit:
        return qrr;
}

void setName(int n, string s) {str[n][0]=s;} // setName - установка имени узла.
string getName(int n){return str[n][0];}// getName - получение имени узла.
void setValue(int n, string s){str[n][1]=s;}// setValue (перегрузить данный метод для установки текстового значения, данные сохраняются в виде текстового значения), 
void setValue(int n, int s){str[n][1]=to_string(s);}// setValue (перегрузить данный метод для установки значения int, данные сохраняются в виде текстового значения), 
void setValue(int n, double s){str[n][1]=to_string(s);}// setValue (перегрузить данный метод для установки значения double, данные сохраняются в виде текстового значения), 
string getValue(int n){return str[n][1];}// getValue - получение текстового значения узла.
bool isInt(int n)// isInt - проверяет можно ли представить данные в виде целого числа. 
{
    bool b=true;
    for(int i=0; i<str[n][1].size(); i++)
    {
        if((str[n][1][i]>'9')or(str[n][1][i]<'0')) {b=false; break;}
    }
    return b;
}
bool isDouble(int n)// isDouble - проверяет можно ли представить данные узла в виде действительного числа. 
{
    bool b=true;
    for(int i=0; i<str[n][1].size(); i++)
    {
        if((str[n][1][i]>'9')or(str[n][1][i]<'0')) 
            if(str[n][1][i]!=',') {b=false; break;}
    }
    return b;
}
int getInt(int n)// getInt - получение данных узла в виде целого числа. При невозможности выдает 0. 
{
    int INT=0;
    if (isInt(n)) n=stoi(str[n][1]);
    return INT;
}
int getDouble(int n)// getDouble - получение данных узла  действительного числа. При невозможности выдает 0.
{
    int INT=0;
    if (isDouble(n)) n=stod(str[n][1]);
    return INT;
}
int getCountSub(int n)// getCountSub - выдает количество потомков.
{
    return vertices[n][0][0]-1;
}
string getSub(int n, int i)// getSub(i) - выдает потомка по порядковому номеру. При невозможности выдает Null.
{
    string s="Null";
    i--;
    if ((vertices[n][0][0]-1)!=0) s=str[vertices[n][i][0]][0];
    return s;
}
string getSub(int n, string s)// getSub(name) - выдает потомка по порядковому имени. При невозможности выдает Null.
{
    string r="Null";
    for(int i=1;i<vertices[n][0][0];i++)
    {
        if(str[vertices[n][i][0]][0]==s) r=to_string(i+1);
    }
    return r;
}
void addSub(int n, string *s)// addSub - добавляет узел потомок.
{
int newsize=size+1;
int ***newvertices;
string **newstr;

newvertices = new int **[newsize];
newstr= new string *[newsize];
for(int i=0;i<size;i++)
    {
        newstr[i]=new string [2];

        newstr[i][0]=str[i][0];
        newstr[i][1]=str[i][1];

        if (i!=n) newvertices[i]=new int *[vertices[i][0][0]];
        else newvertices[i]=new int *[vertices[i][0][0]+1];
        if(vertices[i][0][0]==1)
            {
                newvertices[i][0] =new int [2];
                newvertices[i][0][0]=vertices[i][0][0];
                newvertices[i][0][1]=vertices[i][0][1];
            }
        else
            for(int j=0;j<vertices[i][0][0];j++)
            {
                newvertices[i][j] =new int [2];
                newvertices[i][j][0]=vertices[i][j][0];
                newvertices[i][j][1]=vertices[i][j][1];
            }
        if (i==n) 
        {
            newvertices[i][vertices[i][0][0]-1][0]=size;
            newvertices[i][vertices[i][0][0]-1][1]=1;
        }
    }
    newvertices[size]=new int *[1];
    newvertices[size][0] =new int [2];
    newvertices[size][0][0]=1;
    newvertices[size][0][1]=1;

    newstr[size]=new string[2];
    newstr[size][0]=s[0];
    newstr[size][1]=s[1];

    delete [] vertices;
    vertices=nullptr;
    delete [] str;
    str=nullptr;

    vertices=newvertices;
    str=newstr;
    size=newsize;

    // delete [] newvertices;
    // newvertices=nullptr;
    // delete [] newstr;
    // newstr=nullptr;
}
};
#include<iostream>
#include<string>
#include "multiplTree.h"
#include"massives.h"
using namespace std;

int main()
{
string name;
name=("file.xml");
string *a=TagsMassiveWithSize(name);

cout<<HowManyTags2(to_string(name));

// int i=0;
// string s;
// while(i<stoi(a[0]))
// {
//     i++;
//     s=a[i];
//     int j=i;
//     while(j<stoi(a[0]))
//     {
//         j++;
//         s=='!'+a[j];
//     }
// }

return 0;
}
