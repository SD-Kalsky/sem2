#include<iostream>
#include <queue>
#include <fstream>
#include<string>

using namespace std;

string to_string(string name)
{
    setlocale(LC_ALL, "Russian");
    char c, *buffer=new char [2];
    string b="", s="", ns="";
    fstream in(name);
    if (in.is_open())
        while (!in.eof())
        {
            c=in.get();
            s+=c;
        }
    in.close();
    int i=0, n=s.size();
    while (i<n-1)
    {
        if(s[i]!='\n') ns+=s[i];
        i++;
    }
    return ns;
}


int HowManyTags(string str)
{
    bool isUnarTag=false, isCommentTag=false, isTag=false; 
    int i=0, n=str.size()-1, count=0;
    while (i<n)  
    {
        if((str[i]=='<')and(str[i+1]=='!')and(str[i+2]=='-')and(str[i+3]=='-')and(!isCommentTag)) {isCommentTag=true;}
        if((str[i]=='<')and((str[i+1]=='!')or(str[i+1]=='?'))and(!isCommentTag)) {isUnarTag=true;}
        
        if((str[i]=='<')and(!isUnarTag)and(!isCommentTag))
        {
            int j=i+1, tagsize=0;
            bool end=false;
            
            while(!end)
            {
                if((str[j]==' ')or(str[j]=='>')) end=true;
                else tagsize++;
                j++;
            }
        
            char* tag=new char[tagsize];
            j=0;end=false;

            while(j<tagsize)
            {
                tag[j]=str[j+i+1];
                j++;
            }
            j=i+tagsize;  
            while(j<n)
            {
                if((str[j]=='<')and(str[j+1]=='/'))
                    {
                        j+=2;
                        int k=0;
                        bool tagend=true;
                        while(k<tagsize)
                        {
                            if(tag[k]!=str[k+j]) {tagend=false; break;}
                            k++;
                        }
                        if (tagend) {count++; end=true; break;}
                    }
                if(end) break;
                j++;   
            }
            i=j;

        }


        if((str[i]=='>')and(isUnarTag)) {isUnarTag=false; count++;}
        if((str[i-2]=='-')and(str[i-1]=='-')and(str[i]=='>')and(isCommentTag)) {isCommentTag=false; count++;}
        i++;
    }
    return count;
}

class tag
{
private:
int size, type; //тип суолта
char *chars;
void init()
{
    chars= new char[size];
}
void destroy()
{
    delete chars;
    chars=nullptr;
    size=0;
    type=0;
}
public:
tag()
{
    type=0;
    init();
}
tag(int n)
{
    size=n;
    init();
    for(int i=0;i<n;i++)
    chars[i]='e';
}
tag(string s)
{
size=s.size();
init();
int i=0;
    while(i<size)
    {
        chars[i]=s[i];
        i++;
    }
}
void to_tag(string s)
{
    destroy();
    size=s.size();
    init();
    int i=0;
    while(i<size)
    {
        chars[i]=s[i];
        i++;
    } 
}
void print()
    {
        int i=0;
        while(size>i) 
        {
            cout<<chars[i];
        }
        cout<<endl;
    }
};

int HowManyTag2(string str)
{
    bool isUnarTag=false, isCommentTag=false, isTag=false;
    string string_tag="";
    tag* tags= new tag[HowManyTags(str)];
    int i=0, n=str.size()-1, count=0, st, en, tagindex=0;
    while (i<n)  
    {
        if((str[i]=='<')and(str[i+1]=='!')and(str[i+2]=='-')and(str[i+3]=='-')and(!isCommentTag)) {isCommentTag=true;}
        if((str[i]=='<')and((str[i+1]=='!')or(str[i+1]=='?'))and(!isCommentTag)) {isUnarTag=true;}
        
        if((str[i]=='<')and(!isUnarTag)and(!isCommentTag))
        {
            st=i;
            int j=i+1, tagsize=0;
            bool end=false;
            
            while(!end)
            {
                if((str[j]==' ')or(str[j]=='>')) end=true;
                else tagsize++;
                j++;
            }
        
            char* tag=new char[tagsize];
            j=0;end=false;

            while(j<tagsize)
            {
                tag[j]=str[j+i+1];
                j++;
            }
            j=i+tagsize;  
            while(j<n)
            {
                if((str[j]=='<')and(str[j+1]=='/'))
                    {
                        j+=2;
                        int k=0;
                        bool tagend=true;
                        while(k<tagsize)
                        {
                            if(tag[k]!=str[k+j]) {tagend=false; break;}
                            k++;
                        }
                        if (tagend) {count++; end=true; en=k+j+1; break;}
                    }
                if(end) break;
                j++;   
                if(j==n) en=j;
            }
            i=j;
            while(st<en)
            {
                string_tag+=str[st];
                st++;
            }
            tags[tagindex].to_tag(string_tag);
            tagindex++;
        }
        if(isCommentTag) string_tag+=str[i];
        if(isUnarTag) string_tag+=str[i];
        if((str[i]=='>')and(isUnarTag)) {isUnarTag=false; tagindex++; string_tag=""; count++;}
        if((str[i-2]=='-')and(str[i-1]=='-')and(str[i]=='>')and(isCommentTag)) {isCommentTag=false; tagindex++; string_tag=""; count++;}
        i++;
    }
    i=0;
    while(i<tagindex)
    {
        tags[i].print();
        i++;
    }
    return count;
}
