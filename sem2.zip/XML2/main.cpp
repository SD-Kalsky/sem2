#include<iostream>
#include "classes.h"
#include<string>

using namespace std;

int main()
{
    string name=("file.xml");
    string s=to_string(name); 
    int n=HowManyTag2(s);
    cout<<n;
    return 0;
}