#include<iostream>
#include "massives.h"
#include <queue>

using namespace std;
queue<int> uniteQueue(queue<int> a,queue<int> b)
{
    while (!b.empty())
    {
        a.push(b.front());
        b.pop();
    }
return a;
}
queue<int> * addNewINT_QUEUE(queue<int> *qrr, int size, queue<int> a)
{
    queue<int> * q =new queue<int>[size+1];
    for (int i=0;i<size;i++)
        q[i]=qrr[i];
    q[size]=a;
    return q;
}

class Graph
{
private:
int size;
int ***vertices;// Ис-исмаhып биирис элэмэҥа  - исмаhып кэтитэ, иккиhэ - өрүт туhа
void destroy()
{
    delete [] vertices;
    vertices=nullptr;
}
void destroy_vertice(int i)
{
    delete vertices[i];
    vertices[i]=nullptr;
}
void destroy_connetion(int i,int j)
{
    delete vertices[i][j];
    vertices[i][j]=nullptr;
}
void init()
{
    int i, j;
    vertices = new int **[size];
    for (i = 0; i < size-1; i++)
    {
        vertices[i] = new int *[2];
        vertices[i][0]= new int[2];
        vertices[i][1] = new int[2];
        vertices[i][0][0] = 2;
        vertices[i][0][1] = 0;
        vertices[i][1][0] = i+1;
        vertices[i][1][1] = 1;
    }
    vertices[size-1] = new int *[2];
    vertices[size-1][0]= new int[1];
    vertices[i][0][0] = 1;
    vertices[i][0][1] = 0;
}
public:
Graph()
{
    size=3;
    init();
}
Graph(int n)
{
    size=n;
    init();
}
void print() //Өрүт туhун уонна түhэр өрүттэрин бичиктиир
{
    for(int i=0;i<size;i++)
    {
        cout<<"The vertice is "<<i+1<<"th "<<" and its value is "<<vertices[i][0][1]<<endl;    
        for(int j=1;j<vertices[i][0][0];j++)
        {
            cout<<"its "<<j<<"th neughbour is "<<vertices[i][j][0]+1<<" and its distant is "<<vertices[i][j][1]<<' '<<endl;
        }
        cout<<endl;
    }
}
void setVertice(int num, int **a)//Иккилээх массивы ылан өрүт оннугар угар
{
    destroy_vertice(num);
    vertices[num]=new int *[a[0][0]];;
    for (int i=0;i<a[0][0]; i++)
    vertices[num][i]=new int [2];

    for (int i=0;i<a[0][0]; i++)
    {
        vertices[num][i][0]=a[i][0];
        vertices[num][i][1]=a[i][1];
    }
}

bool isThereWay(int a, int b) //Биирис өрүт иккискэ түhүү уhунун биэрэр
{
    bool c{false};
    int j=1;
    while(j<vertices[a][0][0])
    {
        if(vertices[a][j][0]==b){c=true;  goto exit;}
        j++;
    }
    j=1;
    while(j<vertices[a][0][0]) 
    {

        if (isThereWay(vertices[a][j][0], b)) {c=true; goto exit;} 
        else j++;    
    }
    exit:
        return c;
}

int HowManyWays(int a, int b) //Төhө суол баарын биэрэр
{
    int n=0;
    int j=1;
        while(j<vertices[a][0][0]) 
        {
            if (isThereWay(vertices[a][j][0], b)) n+=HowManyWays(vertices[a][j][0], b);
            else 
                if(vertices[a][j][0]==b) n++;
                j++;    
        }
    return n;
}

int theWayLength(int a, int b) //Биир өрүттэн иккис өрүккэ суол уhунун булар
{
    int i{1},j{1}, l{vertices[a][j][1]};
    while (j<vertices[a][0][0])
    {
        if(vertices[a][j][0]==b){goto exit;}
        j++;
    }
    j=1;
    while (j<vertices[a][0][0])
    {
        if(isThereWay(vertices[a][j][0],b)){l+=theWayLength(vertices[a][j][0],b); goto exit;}
        j++;
    }
    exit:
    return l;
}

queue<int> getWay(int a, int b) //Биир өрүттэн иккис өрүккэ суолу биэрэр
{
    queue<int> qrr;
    qrr.push(a);
    int i{1};
    if (isThereWay(a,b)==false) goto exit;
    while (i<vertices[a][0][0])
    {
        if(vertices[a][i][0]==b){qrr.push(b); goto exit;}
        i++;
    }
    i=1;
    while (i<vertices[a][0][0])
    {
        if(isThereWay(vertices[a][i][0],b)){qrr=uniteQueue(qrr,getWay(vertices[a][i][0],b)); goto exit;}
        i++;
    }
    exit:
        return qrr;
}

queue<int> getWay2(int a, int b) 
{
queue<int> q;
int j=1;
    for(int i=0;i<size;i++)
    {
        vertices[i][j][0];
    }
    return q;
}
};