#include<iostream>
#include"graph.h"

using namespace std;

int main()
{
    int number=6;
    Graph g(number);

    // int **array;
    // array = new int *[3];
    // array[0] = new int [2]{3,0};
    // array[1] = new int [2]{4,1};
    // array[2] = new int [2]{5,1};
    // g.setVertice(3,array);
    // delete [] array;
    // array=nullptr;
    // array = new int *[1];
    // array[0] = new int [2]{1,0};
    // g.setVertice(2,array);
    // delete [] array;
    // array=nullptr;
    // array = new int *[3];
    // array[0] = new int [2]{3,0};
    // array[1] = new int [2]{2,1};
    // array[2] = new int [2]{3,1};
    // g.setVertice(1,array);

    // int **array;
    // array = new int *[2];
    // array[0] = new int [2]{2,0};
    // array[1] = new int [2]{5,1};
    // g.setVertice(1,array);
    // g.setVertice(2,array);
    // g.setVertice(3,array);
    // g.setVertice(4,array);
    // delete [] array;
    // array=nullptr;
    // array = new int *[5];
    // array[0] = new int [2]{5,0};
    // array[1] = new int [2]{1,1};
    // array[2] = new int [2]{2,1};
    // array[3] = new int [2]{3,1};
    // array[4] = new int [2]{4,1};
    // g.setVertice(0,array);

    g.print();

    //cout<<g.HowManyWays(0,5)<<endl;
    queue<int> qrr;
    int num; cin>>num; cout<<endl;
    qrr=g.getWay(0,num);
    while (!qrr.empty())
    {
        cout<<qrr.front()<<' ';
        qrr.pop();
    }
    return 0;
}