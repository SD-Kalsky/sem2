#include<iostream>
using namespace std;
void help_massives()
{
cout<<"SizeInMassive - иэнэ маннайгы сыыhыгар баар массиб"<<endl;
cout<<"bubble_sort_int(int *a,int size) - int массибы хабах сортуур"<<endl;

}
void addNew_INT(int *a, int n)
{
    
}


void bubble_sort_int(int *a,int size)
{
    int temp;
    for (int j{1}; j<size; j++)
    for (int i{0}; i<size-j; i++) 
    {
        if(a[i+1]<a[i])
        {
            temp=a[i];
            a[i]=a[i+1];
            a[i+1]=temp;
        }
    }
}

void PrintIntSizeInMassives(int *a)
{
    for(int i=1;i<a[0];i++)
        cout<<a[i]<<' ';
}
int* AddIntSizeInMassives(int *a,int n)
{
    int i;
    int*arr= new int[a[0]+1];
    for(i=0;i<a[0];i++)
        arr[i]=a[i];
    arr[a[0]+1]=n;
    return arr;
}
int* SumSizeInMassives(int *a,int *b)
{
    int i, size=a[0]+b[0]-1;
    int*arr= new int[size];
    for(i=1;i<a[0];i++)
        arr[i]=a[i];
    for(int j=1;i<size;i++)
        {
            j++;
            arr[i]=b[j];
        }
    return arr;
}
